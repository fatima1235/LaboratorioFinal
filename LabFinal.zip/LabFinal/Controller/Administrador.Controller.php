<?php
    Class Administrador
    {
        public $admin;
        public $smarty;

        public function __construct()
        {
            $this->admin=new Admin();
            $this->smarty=new Smarty();
        }

        public function Usuario()
        {
            $nombre=$_POST['Nombre'];
            $apellido=$_POST['Apellido'];
            $correo=$_POST['Correo'];
            $usuario=$_POST['Usuario'];
            $fecha=$_POST['Fecha'];
            $pass=$_POST['password'];
            $rol=$_POST['rol'];

            $this->admin->CrearUsuario($nombre,$apellido,$correo,$usuario,$fecha,$pass,$rol);
            $this->smarty->assign('nav', 'admin');
            $this->smarty->assign('title', 'Administrador');
            $this->smarty->display('Administrador.tpl');
        }
        public function AgregarP()
        {
            $nombrep=$_POST['nombre'];
            $codigop=$_POST['codigo'];
            $descp=$_POST['desc'];
            $cantp=$_POST['cantidad'];
            $prep=$_POST['precio'];
            $fechap=$_POST['fecha'];
            
            $this->admin->CargarProducto($nombrep,$codigop,$descp,$cantp,$prep,$fechap); 

            $this->smarty->assign('nav', 'admin');
            $this->smarty->assign('title', 'Administrador');
            $this->smarty->display('Administrador.tpl');
            
        }

    }
?>