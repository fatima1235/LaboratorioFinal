<?php
    Class Trabajador
    {
        public $trab;
        public $smarty;
        //public $mostrar;
        public function __construct()
        {
            $this->trab=new Trab();
            $this->smarty=new Smarty();
            //$this->$mostrar=new Mostrar();
        }

        public function Entrada()
        {
            $cantidad=$_POST['cantidad'];
            $codigo=$_POST['codigo'];

             $this->trab->CargarEntrada($codigo,$cantidad); 

            $this->smarty->assign('nav',"trabaj");
            $this->smarty->assign('title','Trabajador');
            $this->smarty->display('Trabajador.tpl');
        }

        public function Salida()
        {
            $cantidad=$_POST['cantidad'];
            $codigo=$_POST['codigo'];
            $this->trab->CargarSalida($codigo,$cantidad);

            $this->smarty->assign('nav',"trabaj");
            $this->smarty->assign('title','Trabajador');
            $this->smarty->display('Trabajador.tpl');
        }

        public function BuscarProducto()
        {
            /*$codigo=$_POST['codigo'];
            $this->trab->BuscarP($codigo);
            */
            echo "en buscar";
        }

        public function MostrarProducto()
        {
            /*$nombre = $_POST['nombre'];
            $desc = $_POST['descripcion'];
            $cantidad = $_POST['cantidad'];
            $precio = $_POST['precio'];
            $fecha = $_POST['fecha']; 

            $m=$mostrar->CargarProducto($nombre, $desc, $cantidad, $precio, $fecha);
            $this->smarty->assign('nav',"trabaj");
            $this->smarty->assign('title','Trabajador');
            $this->smarty->display('Trabajador.tpl');
            */
            echo "en mostrar";
        }
    }
?>