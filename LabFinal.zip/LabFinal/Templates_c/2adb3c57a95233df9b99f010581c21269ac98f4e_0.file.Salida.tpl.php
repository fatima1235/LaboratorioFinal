<?php
/* Smarty version 3.1.39, created on 2021-08-19 02:15:33
  from 'C:\xampp2\htdocs\LabFinal\Trabajador\Salida.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611da2a5f20e32_03372339',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2adb3c57a95233df9b99f010581c21269ac98f4e' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\LabFinal\\Trabajador\\Salida.tpl',
      1 => 1629332128,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611da2a5f20e32_03372339 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row" aling="center">
    <h5>Salida del producto</h5>
    <form method="POST" action="?controller=Trabajador&method=Salida" class="col s8">

        <div class="row">
            <div class="input-field col s8">
                <input id="codigo" type="text" class="validate" required="" name="codigo"/>
                <label for="codigo">Código del Producto</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="Fecha" type="date" class="validate" required="" name="Fecha"/>
                <label for="Fecha">Fecha del movimiento</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="cantidad" type="text" class="validate" required="" name="cantidad"/>
                <label for="cantidad">Cantidad del Producto</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input class="btn waves-effect waves-light" type="submit"   name="action"/>
            </div>
        </div>
    </form>
</div><?php }
}
