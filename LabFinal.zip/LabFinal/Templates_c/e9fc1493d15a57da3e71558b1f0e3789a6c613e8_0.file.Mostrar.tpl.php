<?php
/* Smarty version 3.1.39, created on 2021-08-19 02:36:51
  from 'C:\xampp2\htdocs\LabFinal\Trabajador\Mostrar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611da7a307c467_91785789',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e9fc1493d15a57da3e71558b1f0e3789a6c613e8' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\LabFinal\\Trabajador\\Mostrar.tpl',
      1 => 1629333409,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611da7a307c467_91785789 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="row" align="center">
    <h5 class="center align">Mostrar Productos</h5>
    <form method="POST" action="?controller=Trabajador&method=MostrarProducto" class="col s8">
</div>
<div class="row" >
    <div class="col s12" >
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Código</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                </tr>          
            </thead>
            
        </table>
    </div>
</div>

<?php }
}
