<?php
/* Smarty version 3.1.39, created on 2021-08-17 03:41:14
  from 'C:\xampp2\htdocs\MVC5toDiver-master\Trabajador\Salida.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611b13ba30a442_10699574',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f7c7e1400180c714e898cacf0b382bbce111ede8' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\MVC5toDiver-master\\Trabajador\\Salida.tpl',
      1 => 1629164458,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611b13ba30a442_10699574 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row" aling="center">
    <h1>Salida del producto</h1>
    <form method="POST" action="?controller=Trabajador&method=Salida" class="col s8">

        <div class="row">
            <div class="input-field col s8">
                <input id="codigo" type="text" class="validate" required="" name="codigo"/>
                <label for="codigo">Código del Producto</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="Fecha" type="date" class="validate" required="" name="Fecha"/>
                <label for="Fecha">Fecha del movimiento</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="cantidad" type="text" class="validate" required="" name="cantidad"/>
                <label for="cantidad">Cantidad del Producto</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input class="btn waves-effect waves-light" type="submit"   name="action"/>
            </div>
        </div>
    </form>
</div><?php }
}
