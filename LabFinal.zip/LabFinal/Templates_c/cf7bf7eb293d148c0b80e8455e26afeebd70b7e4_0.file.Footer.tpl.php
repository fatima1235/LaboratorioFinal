<?php
/* Smarty version 3.1.39, created on 2021-06-11 16:37:47
  from 'C:\xampp\htdocs\MVC5toDiver\Templates\Cabeceras\Footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60c3753b1d7874_45958077',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cf7bf7eb293d148c0b80e8455e26afeebd70b7e4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\MVC5toDiver\\Templates\\Cabeceras\\Footer.tpl',
      1 => 1623420607,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60c3753b1d7874_45958077 (Smarty_Internal_Template $_smarty_tpl) {
?><!--JavaScript at end of body for optimized loading-->
      <?php echo '<script'; ?>
 type="text/javascript" src="Framework/Materialize/js/materialize.min.js"><?php echo '</script'; ?>
>
    </body>
  </html>

  <?php }
}
