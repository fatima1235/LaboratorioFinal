<?php
/* Smarty version 3.1.39, created on 2021-08-20 23:23:37
  from 'C:\xampp2\htdocs\LabFinal\Trabajador\Buscar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_61201d591f1d85_98589802',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '61364163c1d92373d5267b7818ae1765beb05f08' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\LabFinal\\Trabajador\\Buscar.tpl',
      1 => 1629426752,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_61201d591f1d85_98589802 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row" aling="center">
    <h5>Busqueda de un producto</h5>
    <form method="POST" action="?controller=Trabajador&method=BuscarProducto" class="col s8">

        <div class="row">
            <div class="input-field col s8">
                <input id="codigo" type="text" class="validate" required="" name="codigo"/>
                <label for="codigo">Código del Producto</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input class="btn waves-effect waves-light" type="submit"   name="action"/>
            </div>
        </div>

        <div class="row" >
            <div class="col s12" >
                <table>
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Código</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                        </tr>          
                    </thead>
                    
                </table>
            </div>
        </div>
    </form>
</div><?php }
}
