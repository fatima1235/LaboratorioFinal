<?php
/* Smarty version 3.1.39, created on 2021-08-18 04:02:16
  from 'C:\xampp2\htdocs\LabFinal\templates\Trabajador.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611c6a28c061a3_79316065',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '3387d126d4d5f8730a562434eee37fb267a61cfa' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\LabFinal\\templates\\Trabajador.tpl',
      1 => 1629168185,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:Templates/Cabeceras/Header.tpl' => 1,
    'file:Templates/Navs/BarraLateral.tpl' => 1,
    'file:Trabajador/Entrada.tpl' => 1,
    'file:Trabajador/Salida.tpl' => 1,
    'file:Trabajador/Buscar.tpl' => 1,
    'file:Trabajador/Mostrar.tpl' => 1,
    'file:Templates/Cabeceras/Footer.tpl' => 1,
  ),
),false)) {
function content_611c6a28c061a3_79316065 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:Templates/Cabeceras/Header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<nav>
        <div class="nav-wrapper">
          <a href="" class="brand-logo">ManejoDeInventarios.com</a>
          <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li>Nathan Juarez </a></li>
            <li>| Trabajador |</a></li>
            <li><a href="">Salir</a></li>
          </ul>
        </div>
      </nav>

      <br/>
      <br/>
      <br/>
 <div class="row">
        <div class="col 4">    
            <?php $_smarty_tpl->_subTemplateRender("file:Templates/Navs/BarraLateral.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        </div>

        <div class="col 1">
        </div>

        <div class="col 7">
            <h1>Bienvenido Trabajador</h1>
            <?php if ((isset($_smarty_tpl->tpl_vars['rol']->value))) {?>
                <?php if ($_smarty_tpl->tpl_vars['rol']->value == 'entrada') {?>
                    <?php $_smarty_tpl->_subTemplateRender('file:Trabajador/Entrada.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                <?php } elseif ($_smarty_tpl->tpl_vars['rol']->value == 'salida') {?>
                    <?php $_smarty_tpl->_subTemplateRender('file:Trabajador/Salida.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                <?php } elseif ($_smarty_tpl->tpl_vars['rol']->value == 'buscar') {?>
                    <?php $_smarty_tpl->_subTemplateRender('file:Trabajador/Buscar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                 <?php } elseif ($_smarty_tpl->tpl_vars['rol']->value == 'mostrar') {?>
                    <?php $_smarty_tpl->_subTemplateRender('file:Trabajador/Mostrar.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
                <?php }?>
            <?php }?>
        </div>
 </div>
  
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 

 <footer class="page-footer">
        <div class="container">
        <div class="row">
            <div class="col l6 s12">
            <h5 class="white-text">¡Muchas gracias por tu visita!</h5>
            <p class="grey-text text-lighten-4">El inventario es uno de los conceptos más importantes para la gestión y administración de una empresa, ya que gracias a ellos podemos conocer la situación real de la empresa. Esta palabra hace referencia a los productos que posee la empresa, pero también a la acción de hacer un inventario en la empresa para el control de que existe ningún problema grave en la empresa.
            </p>
            </div>
            <div class="col l4 offset-l2 s12">
            <h5 class="white-text">Redes Sociales</h5>
            <ul>
                <li><a class="grey-text text-lighten-3">Para poder contactarte con nosotros, puedes usar las siguientes plataformas:</a></li>
                <li><a class="grey-text text-lighten-3">Instagram: @manejodeinventarios</a></li>
                <li><a class="grey-text text-lighten-3">Facebook: Manejo de Inventarios</a></li>
                <li><a class="grey-text text-lighten-3">Gmail: manejodeinventarios@gmail.com</a></li>
            </ul>
            </div>
        </div>
        </div>
        <div class="footer-copyright">
        <div class="container">
        © 2021 Copyright Text
        <a class="grey-text text-lighten-4 right" href="#!">¡Trabaja para nosotros!</a>
        </div>
        </div>
</footer>

<?php $_smarty_tpl->_subTemplateRender("file:Templates/Cabeceras/Footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
