<?php
/* Smarty version 3.1.39, created on 2021-07-07 20:27:47
  from 'C:\xampp\htdocs\MVC5toDiver\templates\Navs\BarraLateral.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_60e5f22362a388_44388270',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a3b13ffaa1cb9b7df63b340e62088ae7c0917bd4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\MVC5toDiver\\templates\\Navs\\BarraLateral.tpl',
      1 => 1625682448,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_60e5f22362a388_44388270 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="col s3">
    <nav class="center-align">Opciones</nav>
    <div class="collection">
    <a href="?class=DireccionesVistas&method=VistaIngresarInvent" class="collection-item">Ingreso de Inventario</a>
    <a href="?class=DireccionesVistas&method=VistaVerInvent" class="collection-item">Ver Inventario</a>
    <a href="?class=Home&method=Inicio" class="collection-item">Salir</a>
    </div>
</div>
<?php }
}
