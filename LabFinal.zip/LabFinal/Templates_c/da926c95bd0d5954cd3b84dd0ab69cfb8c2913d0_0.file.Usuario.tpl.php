<?php
/* Smarty version 3.1.39, created on 2021-08-17 00:27:49
  from 'C:\xampp2\htdocs\MVC5toDiver-master\Administrador\Usuario.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611ae66518eb53_72091394',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'da926c95bd0d5954cd3b84dd0ab69cfb8c2913d0' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\MVC5toDiver-master\\Administrador\\Usuario.tpl',
      1 => 1628991618,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611ae66518eb53_72091394 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row" aling="center">
    <form method="POST" action="?controller=Administrador&method=Usuario" class="col s8">

        <div class="row">
            <div class="input-field col s8">
                <input id="Nombre" type="text" class="validate" required="" name="Nombre"/>
                <label for="Nombre">Nombre</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="Apellido" type="text" class="validate" required="" name="Apellido"/>
                <label for="Apellido">Apellido</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="Correo" type="email" class="validate" required="" name="Correo"/>
                <label for="Correo">Correo</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="Usuario" type="text" class="validate" required="" name="Usuario"/>
                <label for="Usuario">Usuario</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="Fecha" type="date" class="validate" required="" name="Fecha"/>
                <label for="Fecha">Fecha</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="password" type="password" class="validate" required="" name="password"/>
                <label for="password">Contraseña</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <select class="browser-default" name="rol">
                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['NombreRol']->value, 'n');
$_smarty_tpl->tpl_vars['n']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['n']->value) {
$_smarty_tpl->tpl_vars['n']->do_else = false;
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['n']->value['Nombre'];?>
"><?php echo $_smarty_tpl->tpl_vars['n']->value['Nombre'];?>
</option>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="input-field col s12">
                <input class="btn waves-effect waves-light" type="submit" name="action">
            </div>
        </div>

    </form>
</div>

<?php }
}
