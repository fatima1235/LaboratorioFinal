<?php
/* Smarty version 3.1.39, created on 2021-08-17 02:53:53
  from 'C:\xampp2\htdocs\MVC5toDiver-master\Trabajador\Entrada.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611b08a1397548_96653756',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a7afa2a920de4e07a737e2831ee27a92d9adaec1' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\MVC5toDiver-master\\Trabajador\\Entrada.tpl',
      1 => 1629161616,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611b08a1397548_96653756 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row" aling="center">
    <h1>Entrada del producto</h1>
    <form method="POST" action="?controller=Trabajador&method=Entrada" class="col s8">

        <div class="row">
            <div class="input-field col s8">
                <input id="codigo" type="text" class="validate" required="" name="codigo"/>
                <label for="codigo">Código del Producto</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="Fecha" type="date" class="validate" required="" name="Fecha"/>
                <label for="Fecha">Fecha del movimiento</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="cantidad" type="text" class="validate" required="" name="cantidad"/>
                <label for="cantidad">Cantidad del Producto</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input class="btn waves-effect waves-light" type="submit"   name="action"/>
            </div>
        </div>
    </form>
</div><?php }
}
