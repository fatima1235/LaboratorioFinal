<?php
/* Smarty version 3.1.39, created on 2021-08-17 04:24:24
  from 'C:\xampp2\htdocs\MVC5toDiver-master\Templates\Cabeceras\Header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611b1dd8016fa4_45412910',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5dfe2bf75a623be507188ab0a52d2bc9efc48f48' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\MVC5toDiver-master\\Templates\\Cabeceras\\Header.tpl',
      1 => 1629167045,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611b1dd8016fa4_45412910 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
  <html>
    <head>
      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="Framework/Materialize/css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>
      <?php if ((isset($_smarty_tpl->tpl_vars['title']->value))) {?>
        <?php echo $_smarty_tpl->tpl_vars['title']->value;?>

      <?php } else { ?>
        Home
      <?php }?>
      </title>
      
    </head>

    <body>

    <?php }
}
