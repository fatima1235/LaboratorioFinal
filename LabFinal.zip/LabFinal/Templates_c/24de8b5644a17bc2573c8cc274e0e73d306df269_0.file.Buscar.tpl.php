<?php
/* Smarty version 3.1.39, created on 2021-08-17 02:33:48
  from 'C:\xampp2\htdocs\MVC5toDiver-master\Trabajador\Buscar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611b03eca1ef10_02659601',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '24de8b5644a17bc2573c8cc274e0e73d306df269' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\MVC5toDiver-master\\Trabajador\\Buscar.tpl',
      1 => 1629158124,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611b03eca1ef10_02659601 (Smarty_Internal_Template $_smarty_tpl) {
}
}
