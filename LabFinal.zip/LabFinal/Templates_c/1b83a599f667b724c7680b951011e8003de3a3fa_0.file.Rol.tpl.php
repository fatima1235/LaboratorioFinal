<?php
/* Smarty version 3.1.39, created on 2021-08-14 20:14:04
  from 'C:\xampp2\htdocs\MVC5toDiver-master\Administrador\Rol.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611807ece82c01_28287664',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1b83a599f667b724c7680b951011e8003de3a3fa' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\MVC5toDiver-master\\Administrador\\Rol.tpl',
      1 => 1628962476,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611807ece82c01_28287664 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="row" aling="center">
    <form method="POST" action="?controller=&method" class="col s8">

        <div class="row">
            <div class="input-field col s8">
                <input id="Nombre" type="text" class="validate" required="" name="Nombre"/>
                <label for="Nombre">Nombre</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input id="Descripcion" type="text" class="validate" required="" name="Descripcion"/>
                <label for="Descripcion">Descripcion</label>
            </div>
        </div>

        <div class="row">
            <div class="input-field col s8">
                <input class="btn waves-effect waves-light" type="submit"   name="action"/>
            </div>
        </div>
    </form>
</div>


 
 <?php }
}
