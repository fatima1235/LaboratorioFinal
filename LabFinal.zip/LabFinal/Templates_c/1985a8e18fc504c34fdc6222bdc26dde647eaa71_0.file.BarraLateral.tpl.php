<?php
/* Smarty version 3.1.39, created on 2021-08-18 03:24:51
  from 'C:\xampp2\htdocs\MVC5toDiver-master\templates\Navs\BarraLateral.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611c6163bde481_47940321',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1985a8e18fc504c34fdc6222bdc26dde647eaa71' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\MVC5toDiver-master\\templates\\Navs\\BarraLateral.tpl',
      1 => 1629249886,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611c6163bde481_47940321 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <nav class="center-align">Opciones</nav>
    <div class="collection">
    <?php if ((isset($_smarty_tpl->tpl_vars['nav']->value))) {?>
        <?php if ($_smarty_tpl->tpl_vars['nav']->value == 'admin') {?>
            <a href="?controller=DireccionNav&method=Usuario" class="collection-item">Crear Usuario</a>
            <a href="?controller=DireccionNav&method=AgregarP" class="collection-item">Agregar Inventario</a>

        <?php } elseif ($_smarty_tpl->tpl_vars['nav']->value == 'trabaj') {?>
            <a href="?controller=DireccionNav&method=Entrada" class="collection-item">Entrada de Inventario</a>
            <a href="?controller=DireccionNav&method=Salida" class="collection-item">Salida de Inventario</a>
            <a href="?controller=DireccionNav&method=BuscarProducto" class="collection-item">Buscar producto</a>
            <a href="?controller=DireccionNav&method=MostrarProducto" class="collection-item">Mostrar productos</a>
        <?php }?>  
    <?php }?>
        <hr/>
        <a href="?controller=Funciones&method=Salir" class="collection-item">Salir</a>
    </div>

<?php }
}
