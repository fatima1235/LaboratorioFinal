<?php
/* Smarty version 3.1.39, created on 2021-08-18 03:54:04
  from 'C:\xampp2\htdocs\LabFinal\Templates\Cabeceras\Footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_611c683c45a3c2_87975077',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '50384308d3972e3b77897cf6aa4e5d17217be0fe' => 
    array (
      0 => 'C:\\xampp2\\htdocs\\LabFinal\\Templates\\Cabeceras\\Footer.tpl',
      1 => 1626303594,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_611c683c45a3c2_87975077 (Smarty_Internal_Template $_smarty_tpl) {
?><!--JavaScript at end of body for optimized loading-->
      <?php echo '<script'; ?>
 type="text/javascript" src="Framework/Materialize/js/materialize.min.js"><?php echo '</script'; ?>
>
    </body>
  </html>

  <?php }
}
