<?php
    class Admin
    {
        public $con;
       public function __construct()
       {
            $this->con = new Conexion();
           
       }

       public function VerRol()
       {
          $query="SELECT * FROM `rol`;";
          $resultado=$this->con->query($query);
          $this->con->close();
          return $resultado;
       }
       public function CrearUsuario($n,$a,$c,$u,$f,$p,$r)
       {
          $query="INSERT INTO `usuario`(`Nombre`, `Apellido`, `Correo`, `Usuario`, `FechaNac`, `Pass`,`Rol_idRol` ) VALUES ('$n','$a','$c','$u','$f','$p','$r');";
          $resultado=$this->con->query($query);
          $this->con->close();
          return $resultado;
       }

       public function CargarProducto($np,$cp,$dp,$fp,$cap,$pp)
       {
         $query="INSERT INTO `producto`(`Nombre`, `Codigo`, `Descripcion`, `FechaIng`, `Cantidad`, `Precio`) VALUES ('$np','$cp','$dp','$fp','$cap','$pp');";
         $resultado=$this->con->query($query);
         $this->con->close();
         return $resultado;
       }
    }
?>