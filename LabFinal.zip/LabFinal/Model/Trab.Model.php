<?php
    Class Trab
    {
        public $con;
        public function __construct()
        {
            $this->con=new Conexion();
        }

        public function CargarEntrada($codigoP, $cantidadP)
        {
            $query="UPDATE `producto` SET `Cantidad`=(`Cantidad`+'$cantidadP') WHERE `Codigo`='$codigoP';";
            $consulta=$this->con->query($query);
            $this->con->close();
            return $consulta;
        }

        public function CargarSalida($codigoP, $cantidadP)
        {
            $query="UPDATE `producto` SET `Cantidad`=(`Cantidad`-'$cantidadP') WHERE `Codigo`='$codigoP';";
            $consulta=$this->con->query($query);
            $this->con->close();
            return $consulta;
        }

        public function BuscarP($codigoP)
        {
            $query="INSERT INTO `producto`(`Nombre`, `Codigo`, `Descripcion`, `FechaIng`, `Cantidad`, `Precio`);";
            $consulta=$this->con->query($query);
            $this->con->close();
            return $consulta;
        }


    }
?>